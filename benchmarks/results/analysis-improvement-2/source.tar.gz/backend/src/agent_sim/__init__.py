"""JAS: Agent Simulation Environment."""
